package com.example.microserviceb.service;

import com.example.microserviceb.client.NotificationClient;
import com.example.microserviceb.model.NotificationEntity;
import com.example.microserviceb.repository.NotificationRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    private final NotificationClient notificationClient;
    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationClient notificationClient, NotificationRepository notificationRepository) {
        this.notificationClient = notificationClient;
        this.notificationRepository = notificationRepository;
    }

    @Retry(name = "notificationRetry", fallbackMethod = "saveNotificationForRetry")
    @CircuitBreaker(name = "notificationCircuitBreaker", fallbackMethod = "saveNotificationForRetry")
    public void notifyFront(String message) {
        notificationClient.sendNotification(message);
    }

    private void saveNotificationForRetry(String message, Exception e) {
        notificationRepository.save(new NotificationEntity(message));
    }
}
