package com.example.microserviceb.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "microservice-a", url = "http://microservice-a")
public interface NotificationClient {
    @PostMapping("/notifications")
    void sendNotification(@RequestBody String message);
}
