package com.example.microserviceb.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class NotificationEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String message;
    private LocalDateTime createdAt = LocalDateTime.now();

    public NotificationEntity() {}
    public NotificationEntity(String message) { this.message = message; }
}
