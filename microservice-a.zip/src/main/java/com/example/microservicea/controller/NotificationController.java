package com.example.microservicea.controller;

import com.example.microservicea.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Sinks;

@Tag(name = "Notifications", description = "API de gestion des notifications")
@RestController
@RequestMapping("/notifications")
public class NotificationController {
    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @Operation(summary = "Envoyer une notification à tous les clients SSE")
    @PostMapping
    public void sendNotification(@RequestBody String message) {
        notificationService.sendNotification(message);
    }

    @Operation(summary = "Recevoir les notifications en temps réel via SSE")
    @GetMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> streamNotifications() {
        return notificationService.getNotificationStream();
    }
}
