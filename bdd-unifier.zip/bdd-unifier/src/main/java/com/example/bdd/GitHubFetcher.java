
package com.example.bdd;

import java.io.IOException;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.util.List;

public class GitHubFetcher {

    public static void fetchHtmlReports(List<String> repos, String org, String outputDir) throws IOException, InterruptedException {
        HttpClient client = HttpClient.newHttpClient();
        Files.createDirectories(Paths.get(outputDir));

        for (String repo : repos) {
            String url = "https://" + org + ".github.io/" + repo + "/index.html";
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                Path path = Paths.get(outputDir, repo + ".html");
                Files.writeString(path, response.body());
                System.out.println("Fetched: " + url);
            } else {
                System.out.println("Failed to fetch: " + url + " (" + response.statusCode() + ")");
            }
        }
    }
}
