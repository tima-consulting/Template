
package com.example.bdd;

import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import java.io.*;
import java.nio.file.*;
import java.util.stream.*;

public class HtmlMerger {

    public static void merge(String inputDir, String outputPath) throws IOException {
        var htmlFiles = Files.list(Paths.get(inputDir))
                .filter(p -> p.toString().endsWith(".html"))
                .collect(Collectors.toList());

        if (htmlFiles.isEmpty()) return;

        Document base = Jsoup.parse(htmlFiles.get(0).toFile(), "UTF-8");
        Element body = base.body();
        body.empty(); // reset content

        int totalScenarios = 0, totalPassed = 0, totalFailed = 0;

        for (Path htmlFile : htmlFiles) {
            Document doc = Jsoup.parse(htmlFile.toFile(), "UTF-8");
            String title = doc.title() != null ? doc.title() : htmlFile.getFileName().toString();

            Element summary = doc.selectFirst(".summary, #summary, .stats");
            if (summary != null) {
                String text = summary.text();
                totalScenarios += extractInt(text, "Scenarios");
                totalPassed += extractInt(text, "Passed");
                totalFailed += extractInt(text, "Failed");
            }

            Element section = body.appendElement("section");
            section.appendElement("h2").text(title);
            section.append(doc.body().html());
        }

        Element globalSummary = body.prependElement("section").attr("id", "global-summary");
        globalSummary.appendElement("h1").text("Global Test Summary");
        Element list = globalSummary.appendElement("ul");
        list.appendElement("li").text("Total Scenarios: " + totalScenarios);
        list.appendElement("li").text("Passed: " + totalPassed);
        list.appendElement("li").text("Failed: " + totalFailed);

        Files.createDirectories(Paths.get(outputPath).getParent());
        Files.writeString(Paths.get(outputPath), base.outerHtml());
        System.out.println("Unified HTML written to: " + outputPath);
    }

    private static int extractInt(String text, String label) {
        String pattern = label + "[:\s]+(\d+)";
        var matcher = java.util.regex.Pattern.compile(pattern, java.util.regex.Pattern.CASE_INSENSITIVE).matcher(text);
        return matcher.find() ? Integer.parseInt(matcher.group(1)) : 0;
    }

    public static void main(String[] args) throws Exception {
        var repos = java.util.List.of("micro1", "micro2", "micro3");
        var org = "ton-org";
        GitHubFetcher.fetchHtmlReports(repos, org, "reports");
        merge("reports", "output/index.html");
    }
}
